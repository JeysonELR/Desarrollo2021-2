/**
 * Clase que contendrá las fechas: Año, Mes y Día. Además de una función Fecha_Actual.  
 */
private abstract class Clase_Fecha {

	private static short Año;

	private static short Mes;

	private static short Día;

	/**
	 * Get para imprimir en pantalla los tres atributos previamente almacenados en en variables tipo short. Variable que permite un mejor uso de la memoria.  
	 */
	private static char GetFecha_Registrada() {
		return 0;
	}

	/**
	 * Método declarado previamente para registrar o imprimir los tres atributos declarados, esto para luego convertirlos y almacenarlos en variables tipo short, o viceversa.
	 */
	private static char Fecha_Registrada(Año,Mes,Día) {
		return 0;
	}

}
