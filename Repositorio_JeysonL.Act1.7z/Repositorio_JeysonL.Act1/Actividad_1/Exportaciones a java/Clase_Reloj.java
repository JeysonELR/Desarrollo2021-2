/**
 * Clase Reloj cual contendrá solo tres atributos de la hora (Hora, Minutos y Segundos), además la función Hora_Actual.
 */
private class Clase_Reloj {

	private static byte Hora;

	private static byte Minutos;

	private static byte Segundos;

	/**
	 * Declaración de función que conviertirá e imprimirá conjuntamente en carácteres la hora desde los bytes declarados en la misma clase.
	 */
	private static char Hora_Actual() {
		return 0;
	}

	/**
	 *  
	 */
	private static void Alarma() {

	}

}
