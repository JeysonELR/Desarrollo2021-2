public class Clase_Persona {

	private int Cédula_ID;

	private int FechaNacimiento;

	private char Nombre;

	private char TSangre_GrupSan;

	private PersonalData_Estudiantes personalData_Estudiantes;

	private PersonalData_Docentes personalData_Docentes;

}
