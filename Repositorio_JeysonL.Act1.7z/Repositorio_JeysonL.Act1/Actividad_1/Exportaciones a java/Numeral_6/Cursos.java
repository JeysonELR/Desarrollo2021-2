import java.util.Collection;

public class Cursos {

	private int CódigoNúmerico;

	private char SalonNúmero;

	private byte CréditosCurso;

	private Collection<Carreras> carreras;

}
