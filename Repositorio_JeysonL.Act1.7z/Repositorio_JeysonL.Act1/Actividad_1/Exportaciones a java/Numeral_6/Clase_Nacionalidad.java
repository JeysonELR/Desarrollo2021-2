import java.util.Collection;

public class Clase_Nacionalidad {

	private char País;

	private char Ciudad;

	private char Departamento;

	private Class_Universidades class_Universidades;

	private Collection<PersonalData_Estudiantes> personalData_Estudiantes;

	private Collection<PersonalData_Docentes> personalData_Docentes;

	private Collection<PersonalData_Estudiantes> personalData_Estudiantes;

	private Collection<PersonalData_Docentes> personalData_Docentes;

}
