import java.util.Collection;

public class Facultad {

	private char NombreCoordinador;

	private Class_Universidades class_Universidades;

	private Collection<PersonalData_Estudiantes> personalData_Estudiantes;

	private Collection<PersonalData_Docentes> personalData_Docentes;

	private Collection<Carreras> carreras;

}
