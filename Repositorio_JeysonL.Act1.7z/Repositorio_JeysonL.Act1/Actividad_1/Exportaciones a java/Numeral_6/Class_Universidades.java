
import java.util.Collection;

/**
Clase que modela las univerisadades de una organización universitaria. 
 */
public class Class_Universidades {

	private char NombreU;

	private char NombreR;

	private char Nacionalidad;

	private Organización_Universitaria organización_Universitaria;

	private Organización_Universitaria organización_Universitaria;

	private Organización_Universitaria organización_Universitaria;

	private Collection<Facultad> facultad;

	private Clase_Nacionalidad clase_Nacionalidad;

	private Organización_Universitaria organización_Universitaria;

}
