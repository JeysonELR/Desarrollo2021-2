import java.util.Collection;

public class PersonalData_Estudiantes {

	private byte Semestres;

	private int FechaIngreso;

	private Collection<Clase_Nacionalidad> clase_Nacionalidad;

	private Clase_Persona clase_Persona;

	private Collection<Facultad> facultad;

	private Collection<PersonalData_Docentes> personalData_Docentes;

	private Collection<Clase_Nacionalidad> clase_Nacionalidad;

}
