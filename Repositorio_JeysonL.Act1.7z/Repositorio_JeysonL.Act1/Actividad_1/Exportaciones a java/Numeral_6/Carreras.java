import java.util.Collection;

public class Carreras {

	private byte Semestres;

	private byte Créditos;

	private char Nivel;

	private Facultad facultad;

	private Collection<Cursos> cursos;

}
