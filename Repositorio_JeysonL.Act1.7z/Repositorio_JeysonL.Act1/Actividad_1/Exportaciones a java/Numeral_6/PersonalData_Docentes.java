import java.util.Collection;

public class PersonalData_Docentes {

	private char Profesión;

	private int Sueldo;

	private Collection<Clase_Nacionalidad> clase_Nacionalidad;

	private Clase_Persona clase_Persona;

	private Collection<PersonalData_Estudiantes> personalData_Estudiantes;

	private Facultad facultad;

	private Collection<Clase_Nacionalidad> clase_Nacionalidad;

}
