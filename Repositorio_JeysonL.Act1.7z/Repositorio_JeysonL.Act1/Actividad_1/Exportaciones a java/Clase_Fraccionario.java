/**
 * Clase que contiene al denominad, numerador y una función división. 
 */
private class Clase_Fraccionario {

	private static int Denominador;

	private static int Numerador;

	/**
	 * Se declarac "División" cual representa la operación propia de una fracción, el resultado de tipo float por su tendencia no real. 
	 */
	private static float División() {
		return 0;
	}

	/**
	 * Declaración de método o función "División" cual operará a los dos atributos declarados en esta misma clase, imprimiendo un resultado usualmente de tipo float. 
	 */
	private static float División(Denominador,Numerador) {
		return 0;
	}

}
