/**
 * Se usa como parámetro la variable "Ciudad" para ser  utilizada para agregar valores de entrada a "NombreU"
 */
public class Class_Universidades {

	private char InfoU;

	private char País;

	private char Departamento;

	private char NombreU;

	private char NombreR;

	private char Nacionalidad;

	/**
	 * Atributo que contendrá diferentes objetos relevantes a la datos personales de los docentes.
	 */
	private char PersonalDataE;

	private char PersonalDataD;

	private char Carrera;

	private byte CréditosCursos;

	private int Cédula_ID;

	private int Cédula/ID;

	private int FechaNacimiento;

	private int FechaIngreso;

	private int Semestres;

	private char Curso;

	private char Curso_n;

	private int CódigoNúmerico;

	private byte CréditosCurso;

	private byte SalonNúmero;

	private byte CréditosCarrera;

	private char Nivel;

	private int Sueldo;

	private char Facultad;

	private char Profesión;

	private Organización_Universitaria organización_Universitaria;

	public char setNacionalidad(char País, char Departamento, char Ciudad) {
		return 0;
	}

	/**
	 * Se espera almacenar todas las Universidades en relación. Notese el n despues del InfoU_, cual cantidad de objetos dentro dentro de Universidad puede ser 1,2,3...n.
	 */
	public char setUniversidadG(char InfoU) {
		return 0;
	}

	public char setUbicaciónG(char País, char Departamento, char Ciudad) {
		return 0;
	}

	/**
	 * Se espera remplazar G por una unanimidad. Es decir, dentro de los atributos InfoU_1, InfoU_1 ...n. Se enlista diferentes componetes para settear/ establecer.
	 */
	public char setInfoUG(char NombreU, char NombreR, char Facultades, char PersonalDataD, char PersonalDataE, char Nacionalidad) {
		return 0;
	}

	/**
	 * Se espera remplazar G por una unanimidad.
	 */
	public void setPersonalDataEG(int Cédula_ID, char Nacionalidad, int FechaNacimiento, char Carrera, byte Semestres, int FechaIngreso) {
		return 0;
	}

	/**
	 * Se entiende que por FacultadG, se espera un nombre propio de la facultad.
	 * 
	 * Curso_n : char
	 */
	public char setFacultadG(char Carrera, char PersonalDataD, char PersonalDataE, char Curso) {
		return 0;
	}

	/**
	 * Se espera que se genere una busqueda entre las listas y esta infomación se emplee.
	 */
	public char GetBusqueda() {
		return 0;
	}

	/**
	 * Se espera nombre indicativo del Curso y no el genérico. Se omite la carrera pues al igual que indicar la facultad o la universidad, genera redundancia.
	 */
	public void setCursoG(int CódigoNúmerico, char PersonalDataE, char PersonalDataD, byte SalonNúmero, byte CréditosCurso) {
		return 0;
	}

	public void setCarreraG(char Curso, byte Semestres, byte CréditosCarrera, char Nivel) {
		return 0;
	}

	/**
	 * Se espera remplazar G por una unanimidad. Se condiciona Facultad para una sola opción.
	 */
	public void setPersonalDataDG(int Cédula_ID, char Profesión, char Nacionalidad, int FechaNacimiento, int Sueldo, char Facultad) {
		return 0;
	}

	public char Get(void ""+Class_Universidades||Attribute||Operation) {
		return 0;
	}

}
