/**
 * Clase que contendrá dos atributos de tipos short y un método que imprima funciones relacionadas a otras clases que puedan recolectar los datos y/o la conversión de los mismos, para que pueda mejorar aún más, el trabajo permitido por la clase.
 */
public class Clase_Proyectíl {

	/**
	 * Se almacena un int  para la distacia, pues se puede entender que para el vector m/s, tiempo es de un segundo por distancia en metros. 
	 */
	public int Velocidad_m/s;

	public short Angulo;

	/**
	 * Se declara el método Datos_Lanzamiento, cual permite visualizar los datos almacenados en la clase en tipo char o funciones que generen un cordenada. Imprimiéndolos aún así , en carácteres que permitan retroalimentar al usuario sobre la trayectoria esperada del proyectíl. 
	 */
	public char getDatos_Lanzamiento() {
		return 0;
	}

	public char setConversor_Velocidad() {
		return 0;
	}

	/**
	 * Se declara el método Datos_Lanzamiento como public para no solo permitir que se visualice los resultados del método, sino tambien para que se empleen en otras funciones. Permitiendo retroalimentar al usuario con un mayor alcance, sobre la trayectoria del proyectíl. 
	 */
	public static void Datos_Lanzamiento(Angulo,Velocidad_m/s) {
		return 0;
	}

}
