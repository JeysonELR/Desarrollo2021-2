import java.util.Collection;

public class Clase_Tienda {

	private static int Teléfono;

	private static char Dirección;

	private static char Nombre;

	private Collection<Producto> producto;

	/**
	 * Solo se puenden obtener 4 tipos de productos: Lácteos,Cárnicos,Enlatados y Frutas. Metodo no requerido pero sugerido independientemente, omitase el caso.
	 */
	public void getTipo(void Producto) {

	}

}
