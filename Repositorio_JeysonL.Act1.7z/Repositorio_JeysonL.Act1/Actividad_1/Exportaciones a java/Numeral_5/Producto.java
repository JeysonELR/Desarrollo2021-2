import java.util.Collection;

public class Producto {

	private char Nombre;

	private int Código_Númerico;

	private char Fecha_Expiración;

	private char Nombre_Fabricante;

	private int Cantidad_Inventario;

	private int Precio_Unitario; 

}
