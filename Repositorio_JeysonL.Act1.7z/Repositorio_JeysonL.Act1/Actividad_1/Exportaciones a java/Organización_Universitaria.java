import java.util.Collection;

public class Organización_Universitaria {

	private Class_Universidades Universidades;

	private Organización_Universitaria Otro;

	private Collection<Class_Universidades> class_Universidades;

	/**
	 *  
	 */
	public void setUniversidades() {

	}

}
